'use strict';
const catalog=window.YB_CATALOG,articles=catalog.articles;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const years=catalog.years||[...new Set(articles.map(a=>a.date.slice(0,4)))];
let year=years.at(-1),month='01',query='';
const yearSelect=document.getElementById('year-select');
yearSelect.innerHTML=years.map(y=>`<option value="${y}">${y}</option>`).join('');yearSelect.value=year;
function render(){
  const terms=query.toLowerCase().split(/\s+/).filter(Boolean);
  const found=articles.filter(a=>a.date.startsWith(year+'-')&&terms.every(t=>(a.date+' '+a.title+' '+a.search).toLowerCase().includes(t)));
  const shown=found.filter(a=>query||a.date.slice(5,7)===month);
  document.getElementById('count').textContent=found.length+' 篇';
  document.getElementById('months').innerHTML=Array.from({length:12},(_,i)=>{const m=String(i+1).padStart(2,'0');return `<button data-month="${m}" class="${month===m&&!query?'active':''}">${i+1}月</button>`}).join('');
  document.getElementById('list').innerHTML=shown.length?shown.map(a=>`<a class="article" href="${esc(a.url)}" target="_blank" rel="noopener"><span class="date">${a.date.slice(5).replace('-','.')}</span><span class="title">${esc(a.title)}<small>${a.stocks} 只股票 · ${a.charts} 张分时${a.note?' · '+esc(a.note):''}</small></span><span class="open">阅读原文 ↗</span></a>`).join(''):'<p class="empty">没有匹配的原文，试试股票全名、六位代码或日期。</p>';
  const stats=catalog.yearStats?.[year]||catalog.stats;
  document.getElementById('coverage').textContent=`${year} 年已收录 ${stats.articles} 篇原文链接，${stats.stocks.toLocaleString()} 只股票。已保存 ${stats.charts.toLocaleString()} / ${stats.stockDays.toLocaleString()} 张真实分时；五项核心指标齐全 ${stats.coreComplete.toLocaleString()} 条。${catalog.fetchNotesByYear?.[year]||catalog.fetchNote||'缺失项保留空缺。'}`;
  document.getElementById('missing').textContent=stats.missingArticles?.length?`本次作者目录中未找到以下交易日的对应原文：${stats.missingArticles.join('、')}。`:'该年度目录覆盖全部交易日；同日多篇文章分别保留原文入口。';
}
document.getElementById('search').addEventListener('input',e=>{query=e.target.value.trim();render()});
document.getElementById('months').addEventListener('click',e=>{const b=e.target.closest('button');if(b){month=b.dataset.month;query='';document.getElementById('search').value='';render()}});
yearSelect.addEventListener('change',e=>{year=e.target.value;render()});
render();
